package com.bashful.onlineshop;

import android.app.*; import android.os.*; import android.graphics.Color; import android.content.*; import android.view.*; import android.widget.*; import java.util.*;

public class MainActivity extends Activity {
    LinearLayout list; EditText search; int cartCount=0; ArrayList<String> cart=new ArrayList<>();
    String[][] products={{"ফ্যাশন পণ্য","৳ 499"},{"গৃহস্থালি পণ্য","৳ 299"},{"গ্যাজেট ও এক্সেসরিজ","৳ 799"},{"সুন্দর উপহার সামগ্রী","৳ 599"}};
    @Override public void onCreate(Bundle b){super.onCreate(b); setContentView(R.layout.activity_main); list=findViewById(R.id.productList); search=findViewById(R.id.search); render("");
      search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){} public void onTextChanged(CharSequence s,int a,int b,int c){render(s.toString());} public void afterTextChanged(android.text.Editable e){}});
      findViewById(R.id.cartButton).setOnClickListener(v->showCart()); }
    void render(String q){list.removeAllViews(); for(String[] p:products) if(q.trim().isEmpty()||p[0].toLowerCase().contains(q.toLowerCase())){ LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(18,18,18,18); card.setBackgroundColor(Color.WHITE); TextView n=new TextView(this); n.setText(p[0]); n.setTextSize(19); n.setTextColor(Color.rgb(27,94,32)); TextView price=new TextView(this); price.setText(p[1]); price.setTextSize(16); Button add=new Button(this); add.setText("কার্টে যোগ করুন"); add.setOnClickListener(v->{cart.add(p[0]+" - "+p[1]); Toast.makeText(this,"কার্টে যোগ হয়েছে",Toast.LENGTH_SHORT).show();}); card.addView(n); card.addView(price); card.addView(add); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,12); list.addView(card,lp); } }
    void showCart(){ StringBuilder s=new StringBuilder("আপনার কার্ট:\n\n"); if(cart.isEmpty())s.append("কার্ট খালি।"); else for(String x:cart)s.append("• ").append(x).append("\n"); new AlertDialog.Builder(this).setTitle("কার্ট").setMessage(s.toString()).setPositiveButton("অর্ডার করুন",(d,w)->order()).setNegativeButton("বন্ধ",null).show(); }
    void order(){ final EditText name=new EditText(this); name.setHint("আপনার নাম ও মোবাইল নম্বর"); new AlertDialog.Builder(this).setTitle("অর্ডার তথ্য").setMessage("নাম ও মোবাইল নম্বর লিখুন").setView(name).setPositiveButton("অর্ডার পাঠান",(d,w)->{cart.clear(); Toast.makeText(this,"আপনার অর্ডার গ্রহণ করা হয়েছে।",Toast.LENGTH_LONG).show();}).setNegativeButton("বাতিল",null).show(); }
}
