# বাশফুল অনলাইন শপ — Android project

Android Studio-তে এই project খুলে Gradle sync করুন। তারপর Build > Build APK(s) দিয়ে debug APK তৈরি করা যাবে।
Release APK বিতরণের আগে নিজের signing key দিয়ে sign করতে হবে।

Demo admin password: 1234

এই starter সংস্করণে পণ্য তালিকা, সার্চ, কার্ট এবং অর্ডার ফর্ম আছে। পণ্যের ছবি, আসল দাম, WhatsApp/ফোন নম্বর, bKash/Nagad ও Firebase/database যুক্ত করতে পরবর্তী কনফিগারেশন প্রয়োজন।
